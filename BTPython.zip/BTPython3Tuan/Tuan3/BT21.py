print('Câu 21:')
import re
values = []
items = [x for x in input("Nhập mật khẩu : ").split(',')]
for a in items:
    if(len(a) <6 or len(a)>12):
        continue
    else:
        pass
    if not re.search("[a-z]", a) :
        continue
    elif not re.search("[0-9]", a):
        continue
    elif not re.search("[A-Z]", a):
        continue
    elif not re.search("[$#@]", a):
        continue
    elif re.search("\s", a):
        continue
    else:
        pass
        values.append(a)
print(",".join(values))