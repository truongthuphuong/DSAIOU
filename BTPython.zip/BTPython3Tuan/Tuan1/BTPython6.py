print('Câu 6: ')
x = int(input('Nhập vào một số: '))
def BinhPhuong(a):
    return a**2
print(x,'^ 2 = ',BinhPhuong(x))
