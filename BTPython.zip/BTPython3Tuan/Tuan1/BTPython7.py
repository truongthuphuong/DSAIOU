print('Câu 7:')
x = int(input('Nhập vào một số nguyên:'))
print('Giá trị tuyệt đối của', x ,'là:', abs(x))
def BinhPhuong(a):
    return a**2
print('(',x,')','^ 2 = ',BinhPhuong(x))