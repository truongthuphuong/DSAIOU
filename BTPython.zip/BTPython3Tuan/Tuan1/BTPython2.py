print('Câu 2:')
x = int(input('Nhập một số nguyên cần tính giai thừa:'))
def GiaiThua(x):
    if(x==0):
        return 1
    return x*GiaiThua(x-1)
print(GiaiThua(x))
