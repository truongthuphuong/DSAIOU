print('Câu 4')
x = input('Nhập vào các giá trị(cách nhau bằng dấu phẩy) :')
list = x.split(',')
tuple = tuple(list)
print(list)
print(tuple)

