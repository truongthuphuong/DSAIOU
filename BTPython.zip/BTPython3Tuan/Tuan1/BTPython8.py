print('Câu 8:')
class Person:
 name = 'Person'

 def __init__(self, name = None):
     self.name=name

a = Person('NguyenVanA')
print (" %s name is %s " % (Person.name, a.name))

b = Person()
b.name='NguyenVanB'
print (" %s name is %s" % (Person.name, b.name))