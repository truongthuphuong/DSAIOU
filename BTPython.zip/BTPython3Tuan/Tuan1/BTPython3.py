print('Câu 3:\n')
x = int(input('Nhập vào một số nguyên: '))
dictinary = dict()
for i in range(1,x+1):
    dictinary[i] = i*i
print(dictinary)

