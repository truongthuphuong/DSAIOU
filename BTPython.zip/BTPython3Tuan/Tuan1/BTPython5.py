print('Câu 5:')
class XuatChuoiInHoa(object):
    def __init__(self):
        self.s = ""
    def IuPut(self):
       self.s= input('Nhập chuỗi: ')
    def OutPut(self):
        print(self.s.upper())
chuoi =  XuatChuoiInHoa()
chuoi.IuPut()
chuoi.OutPut()


