print('Câu 19:')
items = [x for x in input("Nhập vào các số cách nhau bằng dấu phẩy: ").split(',')
         if int(x)%2 !=0 ]
print(','.join(items))