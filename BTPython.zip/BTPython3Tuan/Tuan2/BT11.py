print('Câu 11:')
items = [x for x in input('Nhập vào chuỗi cách nhau bởi dấu phẩy: ').split(',')]
items.sort()
print(','.join(items))