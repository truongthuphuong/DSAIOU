print('Câu 15:')
values =[]
for i in range(1000,3001):
    s = str(i)
    if(int(s)%2==0):
        values.append(s)
print(','.join(values))