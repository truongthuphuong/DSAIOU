print('Câu 9:')
import math
print('Q = sqr (2*C*D)/H , C = 50 , H = 30')
C = 50
H = 30
value = []
items = (x for x in input("Nhập giá trị của D: ").split(','))
for D in items:
    value.append(str(int(round (math.sqrt((2*C*float(D))/H)))))
print(','.join(value))
