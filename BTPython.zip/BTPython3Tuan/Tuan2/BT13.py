print('Câu 13:')
items = [x for x in input('Nhập vào chuỗi cách nhau bởi khoảng trắng: ').split(' ')]

items.sort()
print(' '.join((sorted(list(set(items))))))