print('Câu 14:')
value =[]
items = [x for x in input('Nhập vào các dãy số : ').split(',')]
for a in items:
    inta = int(a,2)
    if not inta%5:
        value.append(a)
print(','.join(value))