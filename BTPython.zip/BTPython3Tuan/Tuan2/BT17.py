print('Câu 17:')
items = input('Nhập vào chuỗi : ')
c = {'InHoa' :0 , 'Thuong':0}
for x in items:
    if x.isupper():
        c['InHoa'] +=1;
    if x.islower():
        c['Thuong'] +=1
print("Số chữ in hoa: %s" % c['InHoa'] )
print("Số chữ thường: %s" % c['Thuong'] )