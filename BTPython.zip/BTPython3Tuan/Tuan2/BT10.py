print('Câu 10:')
input_str = input('Nhập X, Y:')
a = [int(x) for x in input_str.split(',')]
rowNum = a[0]
colNum = a[1]
list = [[0 for col in range(colNum)] for row in range(rowNum)]
for row in range(rowNum):
    for col in range(colNum):
        list[row][col] = row*col
print(list)