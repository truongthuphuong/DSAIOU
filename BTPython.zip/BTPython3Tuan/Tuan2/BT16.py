print('Câu 16:')
items = input('Nhập vào chuỗi có số và chữ: ')
c = {'Chu' :0 , 'So':0}
for x in items:
    if x.isdigit():
        c['So'] +=1;
    if x.isalpha():
        c['Chu'] +=1
print("Số chữ cái: %s" % c['Chu'] )
print("Số chữ số: %s" % c['So'] )