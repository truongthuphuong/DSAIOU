"""
#cau 1:
j =[]
for i in range (2000,3200):
    if (i%7==0) and (i%5!=0):
        j.append(str(i))
print('-'.join(j)) #join để nối các chuỗi """
"""#Cau 2:
x=int(input("Nhập số cần tính giai thừa:"))
def giaithua(x):
    if x == 0:
        return 1
    return x * giaithua(x - 1)
print (giaithua(x))"""

""""#cau3
x=int(input('nhap so:'))
dictionary=dict()
for i in range (1, x+1):
    dictionary[i]=i*i
print(dictionary)"""
"""#cau4
s=input("Nhập vào các giá trị:")
l=s.split(",")
t=tuple(l)
print (l)
print (t)"""
""""#cau 6:
x=int(input("Nhập một số:"))
def square(num):
  return num ** 2
print(square(2))
print(square(3))
print(square(x))"""
"""#cau7:
print(abs.__doc__)
print(int.__doc__)
print(input.__doc__)
def square(num):
    return num ** 2

print (square.__doc__)"""
#CAU8:
